# -*- coding: utf-8 -*-
import os
import re
import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = "service.bb.bingie.lastshipplayer"
ADDON = xbmcaddon.Addon(ADDON_ID)

BINGIE_HELPER_ID = "plugin.video.tmdb.bingie.helper"
PLAYER_FILENAME = "BBPlayer4Lastship.json"

TARGET_DIR = "special://profile/addon_data/plugin.video.tmdb.bingie.helper/reconfigured_players/"
TARGET_FILE = TARGET_DIR + PLAYER_FILENAME
SETTINGS_FILE = "special://profile/addon_data/plugin.video.tmdb.bingie.helper/settings.xml"

SOURCE_FILE = os.path.join(
    ADDON.getAddonInfo("path"),
    "resources",
    "players",
    PLAYER_FILENAME
)

MOVIE_SETTING_VALUE = f"{PLAYER_FILENAME} search_movie"
EPISODE_SETTING_VALUE = f"{PLAYER_FILENAME} search_episode"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def read_text(path):
    try:
        if not xbmcvfs.exists(path):
            return None
        f = xbmcvfs.File(path, "r")
        data = f.read()
        f.close()
        return data
    except Exception as e:
        log(f"Fehler beim Lesen von {path}: {e}", xbmc.LOGERROR)
        return None


def write_text(path, content):
    try:
        f = xbmcvfs.File(path, "w")
        f.write(content)
        f.close()
        return True
    except Exception as e:
        log(f"Fehler beim Schreiben von {path}: {e}", xbmc.LOGERROR)
        return False


def ensure_dir(path):
    try:
        if not xbmcvfs.exists(path):
            ok = xbmcvfs.mkdirs(path)
            log(f"Ordner erstellt: {path} -> {ok}", xbmc.LOGDEBUG)
        return xbmcvfs.exists(path)
    except Exception as e:
        log(f"Fehler beim Erstellen des Ordners {path}: {e}", xbmc.LOGERROR)
        return False


def copy_player_json():
    if not xbmcvfs.exists(SOURCE_FILE):
        log(f"Quell-JSON nicht gefunden: {SOURCE_FILE}", xbmc.LOGERROR)
        return False

    if not ensure_dir(TARGET_DIR):
        log(f"Zielordner konnte nicht erstellt werden: {TARGET_DIR}", xbmc.LOGERROR)
        return False

    source_data = read_text(SOURCE_FILE)
    target_data = read_text(TARGET_FILE)

    if source_data is None:
        log("Quell-JSON konnte nicht gelesen werden", xbmc.LOGERROR)
        return False

    if target_data == source_data:
        log("Player-JSON ist bereits aktuell", xbmc.LOGINFO)
        return True

    if xbmcvfs.exists(TARGET_FILE):
        try:
            xbmcvfs.delete(TARGET_FILE)
        except Exception as e:
            log(f"Bestehende Ziel-JSON konnte nicht gelöscht werden: {e}", xbmc.LOGWARNING)

    ok = xbmcvfs.copy(SOURCE_FILE, TARGET_FILE)
    log(f"Player-JSON kopiert: {ok}", xbmc.LOGINFO if ok else xbmc.LOGERROR)
    return ok


def set_bingie_settings_via_api():
    try:
        bingie = xbmcaddon.Addon(BINGIE_HELPER_ID)
        bingie.setSetting("default_player_movies", MOVIE_SETTING_VALUE)
        bingie.setSetting("default_player_episodes", EPISODE_SETTING_VALUE)
        log("Bingie-Settings per API gesetzt", xbmc.LOGINFO)
        return True
    except Exception as e:
        log(f"Setzen per API fehlgeschlagen: {e}", xbmc.LOGWARNING)
        return False


def patch_or_insert_setting(xml, setting_id, value):
    pattern = rf'(<setting\s+id="{re.escape(setting_id)}">)(.*?)(</setting>)'

    if re.search(pattern, xml, flags=re.DOTALL):
        xml = re.sub(
            pattern,
            rf'\1{value}\3',
            xml,
            flags=re.DOTALL
        )
    else:
        insert_line = f'    <setting id="{setting_id}">{value}</setting>\n'
        if "</settings>" in xml:
            xml = xml.replace("</settings>", insert_line + "</settings>")
        else:
            xml = f"<settings>\n{insert_line}</settings>"
    return xml


def patch_settings_xml():
    current = read_text(SETTINGS_FILE)

    if current is None:
        log("settings.xml nicht vorhanden, neue Datei wird erstellt", xbmc.LOGINFO)
        current = "<settings>\n</settings>"

    updated = current
    updated = patch_or_insert_setting(updated, "default_player_movies", MOVIE_SETTING_VALUE)
    updated = patch_or_insert_setting(updated, "default_player_episodes", EPISODE_SETTING_VALUE)

    if updated == current:
        log("settings.xml bereits korrekt", xbmc.LOGINFO)
        return True

    ok = write_text(SETTINGS_FILE, updated)
    log(f"settings.xml aktualisiert: {ok}", xbmc.LOGINFO if ok else xbmc.LOGERROR)
    return ok


def is_addon_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except Exception:
        return False


def run():
    log("Service gestartet", xbmc.LOGINFO)

    monitor = xbmc.Monitor()
    if monitor.waitForAbort(5):
        return

    if not is_addon_installed(BINGIE_HELPER_ID):
        log(f"{BINGIE_HELPER_ID} ist nicht installiert", xbmc.LOGWARNING)
        return

    copy_ok = copy_player_json()
    api_ok = set_bingie_settings_via_api()
    xml_ok = patch_settings_xml()

    log(f"Fertig. copy_ok={copy_ok}, api_ok={api_ok}, xml_ok={xml_ok}", xbmc.LOGINFO)


if __name__ == "__main__":
    run()