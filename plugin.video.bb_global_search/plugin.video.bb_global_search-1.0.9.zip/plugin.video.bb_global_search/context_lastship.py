# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import urllib.parse as urlparse
import re

ADDON = xbmcaddon.Addon('plugin.video.bb_global_search')
ADDON_ID = ADDON.getAddonInfo('id')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def clean_search_title(title):
    title = title or ''

    # Entfernt [Tags]
    title = re.sub(r'\[[^\]]*\]', '', title).strip()

    # Entfernt Jahr (z. B. (2022))
    title = re.sub(r'\s*\((19|20)\d{2}\)\s*$', '', title).strip()

    # Entfernt typische Release-Tags
    title = re.sub(
        r'\b(Webrip|WEBRIP|WebRip|BluRay|BRRip|HDRip|DVDRip|HDTV|1080p|720p|2160p|4K|x264|x265|h264|h265)\b',
        '',
        title,
        flags=re.IGNORECASE
    ).strip()

    # Mehrere Leerzeichen bereinigen
    title = re.sub(r'\s+', ' ', title).strip()

    return title


def detect_media_type():
    dbtype = (
        xbmc.getInfoLabel('ListItem.DBTYPE') or
        xbmc.getInfoLabel('ListItem.DBType') or
        xbmc.getInfoLabel('ListItem.VideoType') or
        ''
    ).lower()

    path = (
        xbmc.getInfoLabel('ListItem.FileNameAndPath') or
        xbmc.getInfoLabel('ListItem.Path') or
        xbmc.getInfoLabel('ListItem.Filename') or
        ''
    ).lower()

    if dbtype in ('tvshow', 'episode', 'season'):
        return 'tv'

    if dbtype == 'movie':
        return 'movie'

    if 'tmdb_type=tv' in path or 'info=seasons' in path or 'action=tvshows' in path:
        return 'tv'

    if 'tmdb_type=movie' in path or 'action=movies' in path:
        return 'movie'

    return 'ask'


def search_lastship(title, media_type):
    clean_title = clean_search_title(title)
    query = urlparse.quote(clean_title, safe='')

    if media_type == 'tv':
        lastship_url = f"plugin://plugin.video.lastship.reborn/?action=tvshows&page=1&query={query}"
        label = "Serie"
    else:
        lastship_url = f"plugin://plugin.video.lastship.reborn/?action=movies&page=1&query={query}"
        label = "Film"

    xbmc.executebuiltin(f'ActivateWindow(10025,"{lastship_url}",return)')

    xbmcgui.Dialog().notification(
        "LastShip Suche",
        f"{label}-Suche: {clean_title}",
        xbmcgui.NOTIFICATION_INFO,
        2000
    )


def main():
    try:
        title = (
            xbmc.getInfoLabel('ListItem.Title') or
            xbmc.getInfoLabel('ListItem.TVShowTitle') or
            xbmc.getInfoLabel('ListItem.Label') or
            ''
        ).strip()

        if not title:
            log("No title found", xbmc.LOGDEBUG)
            return

        media_type = detect_media_type()
        log(f"Detected media type: {media_type}", xbmc.LOGDEBUG)

        if media_type == 'ask':
            selected = xbmcgui.Dialog().select(
                "In LastShip suchen als",
                ["Film", "Serie"]
            )

            if selected == -1:
                return

            media_type = 'movie' if selected == 0 else 'tv'

        search_lastship(title, media_type)

    except Exception as e:
        log(f"Error in global LastShip search: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "LastShip Suche",
            "Suche fehlgeschlagen",
            xbmcgui.NOTIFICATION_ERROR,
            1500
        )


if __name__ == '__main__':
    main()