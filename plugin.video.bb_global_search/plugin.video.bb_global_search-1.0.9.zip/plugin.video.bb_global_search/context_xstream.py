# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import urllib.parse as urlparse
import re

ADDON = xbmcaddon.Addon('plugin.video.bb_global_search')
ADDON_ID = ADDON.getAddonInfo('id')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def clean_search_title(title):
    title = title or ''

    title = re.sub(r'\[[^\]]*\]', '', title).strip()
    title = re.sub(r'\s*\((19|20)\d{2}\)\s*$', '', title).strip()

    title = re.sub(
        r'\b(Webrip|WEBRIP|WebRip|BluRay|BRRip|HDRip|DVDRip|HDTV|1080p|720p|2160p|4K|x264|x265|h264|h265)\b',
        '',
        title,
        flags=re.IGNORECASE
    ).strip()

    title = re.sub(r'\s+', ' ', title).strip()
    return title


def search_xstream(title):
    clean_title = clean_search_title(title)
    query = urlparse.quote(clean_title, safe='')

    xstream_url = (
        "plugin://plugin.video.xstream/"
        f"?function=globalSearch&params=0&site=globalSearch"
        f"&title=Global%20Suche&searchterm={query}"
    )

    xbmc.executebuiltin(f'ActivateWindow(10025,"{xstream_url}",return)')

    xbmcgui.Dialog().notification(
        "xStream Suche",
        f"Suche: {clean_title}",
        xbmcgui.NOTIFICATION_INFO,
        2000
    )

    log(f"xStream search executed: {xstream_url}", xbmc.LOGDEBUG)


def main():
    try:
        title = (
            xbmc.getInfoLabel('ListItem.Title') or
            xbmc.getInfoLabel('ListItem.TVShowTitle') or
            xbmc.getInfoLabel('ListItem.Label') or
            ''
        ).strip()

        if not title:
            log("No title found", xbmc.LOGDEBUG)
            return

        search_xstream(title)

    except Exception as e:
        log(f"Error in global xStream search: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "xStream Suche",
            "Suche fehlgeschlagen",
            xbmcgui.NOTIFICATION_ERROR,
            1500
        )


if __name__ == '__main__':
    main()