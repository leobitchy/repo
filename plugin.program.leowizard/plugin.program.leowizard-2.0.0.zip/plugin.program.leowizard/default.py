import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
import zipfile
import shutil
import json
import urllib.request

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

# Externe Build-ZIP (GitHub Release Asset empfohlen)
BUILD_ZIP_URL = "https://github.com/leobitchy/leosystems-repo/releases/download/leoaddons/addons.zip"

# Lokaler temporärer Speicherort
TEMP_DIR = xbmcvfs.translatePath("special://temp/plugin.program.leowizard")
DOWNLOADED_ZIP = os.path.join(TEMP_DIR, "addons.zip")

# Lokale Dateien im Addon
SRC_GUISETTINGS = os.path.join(ADDON_PATH, 'resources', 'guisettings.xml')
SRC_SOURCES = os.path.join(ADDON_PATH, 'resources', 'sources.xml')

# Kodi Pfade
KODI_HOME = xbmcvfs.translatePath("special://home")
KODI_USERDATA = xbmcvfs.translatePath("special://home/userdata")
DEST_GUISETTINGS = os.path.join(KODI_USERDATA, 'guisettings.xml')
DEST_SOURCES = os.path.join(KODI_USERDATA, 'sources.xml')

# Diese Addons sollen entfernt oder mindestens deaktiviert werden
BLOCKED_ADDONS = [
    "plugin.video.xship",
    "plugin.video.global.xship_search"
]


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"LeoWizard: {msg}", level)


def jsonrpc(method, params=None):
    payload = {
        "jsonrpc": "2.0",
        "method": method,
        "id": 1
    }
    if params is not None:
        payload["params"] = params

    result = xbmc.executeJSONRPC(json.dumps(payload))
    return json.loads(result)


def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)


def download_file(url, dest_path):
    ensure_dir(os.path.dirname(dest_path))

    dialog = xbmcgui.DialogProgress()
    dialog.create("LeoWizard", "Lade Build herunter...")

    try:
        with urllib.request.urlopen(url) as response:
            total = response.headers.get("Content-Length")
            total = int(total) if total else 0

            with open(dest_path, "wb") as out_file:
                downloaded = 0
                while True:
                    chunk = response.read(1024 * 256)
                    if not chunk:
                        break

                    out_file.write(chunk)
                    downloaded += len(chunk)

                    if total > 0:
                        percent = int(downloaded * 100 / total)
                        mb_done = downloaded / (1024 * 1024)
                        mb_total = total / (1024 * 1024)
                        dialog.update(percent, f"Lade Build herunter...\n{mb_done:.1f} / {mb_total:.1f} MB")
                    else:
                        dialog.update(0, f"Lade Build herunter...\n{downloaded // 1024} KB")

                    if dialog.iscanceled():
                        raise Exception("Download abgebrochen.")

        dialog.close()
        log(f"Build ZIP heruntergeladen: {dest_path}", xbmc.LOGINFO)
        return True

    except Exception as e:
        try:
            dialog.close()
        except Exception:
            pass
        log(f"Fehler beim Download: {e}", xbmc.LOGERROR)
        return False


def extract_build_zip(zip_path):
    dialog = xbmcgui.Dialog()
    dialog.notification("LeoWizard", "Entpacke Build...", xbmcgui.NOTIFICATION_INFO, 3000)

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        for member in zip_ref.namelist():

            # addons → special://home/addons
            if member.startswith("addons/"):
                target_path = os.path.join(KODI_HOME, member)
            
            # addondata → userdata/addon_data
            elif member.startswith("addondata/"):
                rel_path = member.replace("addondata/", "")
                target_path = os.path.join(KODI_USERDATA, "addon_data", rel_path)
            
            else:
                continue

            # Ordner erstellen
            if member.endswith("/"):
                os.makedirs(target_path, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                with zip_ref.open(member) as source, open(target_path, "wb") as target:
                    shutil.copyfileobj(source, target)


def addon_exists(addon_id):
    try:
        result = jsonrpc("Addons.GetAddons", {
            "properties": ["name", "enabled"]
        })
        if "result" in result and "addons" in result["result"]:
            for addon in result["result"]["addons"]:
                if addon.get("addonid") == addon_id:
                    return True
    except Exception as e:
        log(f"Fehler bei Addon-Prüfung für {addon_id}: {e}", xbmc.LOGERROR)
    return False


def disable_addon(addon_id):
    try:
        result = jsonrpc("Addons.SetAddonEnabled", {
            "addonid": addon_id,
            "enabled": False
        })
        if "error" in result:
            log(f"Addon konnte nicht deaktiviert werden: {addon_id} - {result['error']}", xbmc.LOGERROR)
            return False
        log(f"Addon deaktiviert: {addon_id}", xbmc.LOGINFO)
        return True
    except Exception as e:
        log(f"Fehler beim Deaktivieren von {addon_id}: {e}", xbmc.LOGERROR)
        return False


def disable_blocked_addons_if_present():
    for addon_id in BLOCKED_ADDONS:
        if addon_exists(addon_id):
            disable_addon(addon_id)
        else:
            log(f"Blockiertes Addon nicht vorhanden: {addon_id}", xbmc.LOGINFO)


def remove_addon_files(addon_id):
    removed_anything = False

    addon_dir = xbmcvfs.translatePath(os.path.join("special://home", "addons", addon_id))
    addon_data_dir = xbmcvfs.translatePath(os.path.join("special://profile", "addon_data", addon_id))

    try:
        if os.path.exists(addon_dir):
            shutil.rmtree(addon_dir, ignore_errors=False)
            log(f"Addon-Ordner gelöscht: {addon_dir}", xbmc.LOGINFO)
            removed_anything = True
    except Exception as e:
        log(f"Fehler beim Löschen von {addon_dir}: {e}", xbmc.LOGERROR)

    try:
        if os.path.exists(addon_data_dir):
            shutil.rmtree(addon_data_dir, ignore_errors=False)
            log(f"Addon-Daten gelöscht: {addon_data_dir}", xbmc.LOGINFO)
            removed_anything = True
    except Exception as e:
        log(f"Fehler beim Löschen von {addon_data_dir}: {e}", xbmc.LOGERROR)

    return removed_anything


def purge_blocked_addons():
    dialog = xbmcgui.Dialog()
    dialog.notification("LeoWizard", "Prüfe unerwünschte Addons...", xbmcgui.NOTIFICATION_INFO, 3000)

    for addon_id in BLOCKED_ADDONS:
        if not addon_exists(addon_id):
            log(f"Addon nicht vorhanden: {addon_id}", xbmc.LOGINFO)
            continue

        dialog.notification("LeoWizard", f"Entferne {addon_id}...", xbmcgui.NOTIFICATION_INFO, 3000)

        disabled = disable_addon(addon_id)
        xbmc.sleep(500)

        removed = remove_addon_files(addon_id)

        if removed:
            log(f"Addon erfolgreich entfernt: {addon_id}", xbmc.LOGINFO)
        elif disabled:
            log(f"Addon konnte nicht gelöscht werden, bleibt aber deaktiviert: {addon_id}", xbmc.LOGWARNING)
        else:
            log(f"Addon konnte weder gelöscht noch deaktiviert werden: {addon_id}", xbmc.LOGERROR)


def enable_all_addons():
    dialog = xbmcgui.Dialog()
    dialog.notification("LeoWizard", "Aktiviere alle Addons...", xbmcgui.NOTIFICATION_INFO, 3000)

    query = '''
    {
        "jsonrpc": "2.0",
        "method": "Addons.GetAddons",
        "params": { "enabled": false },
        "id": 1
    }
    '''
    result = xbmc.executeJSONRPC(query)
    addons = json.loads(result)

    if "result" in addons and "addons" in addons["result"]:
        for addon in addons["result"]["addons"]:
            addonid = addon["addonid"]
            xbmc.executeJSONRPC(f'''
            {{
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {{
                    "addonid": "{addonid}",
                    "enabled": true
                }},
                "id": 1
            }}
            ''')

    log("Alle Addons aktiviert.", xbmc.LOGINFO)


def set_skin(skin_id):
    query = f'''
    {{
        "jsonrpc": "2.0",
        "method": "Settings.SetSettingValue",
        "params": {{
            "setting": "lookandfeel.skin",
            "value": "{skin_id}"
        }},
        "id": 1
    }}
    '''
    xbmc.executeJSONRPC(query)
    log(f"Skin auf {skin_id} gesetzt.", xbmc.LOGINFO)


def cleanup_downloaded_zip():
    try:
        if os.path.exists(DOWNLOADED_ZIP):
            os.remove(DOWNLOADED_ZIP)
            log(f"Temporäre ZIP gelöscht: {DOWNLOADED_ZIP}", xbmc.LOGINFO)
    except Exception as e:
        log(f"Temporäre ZIP konnte nicht gelöscht werden: {e}", xbmc.LOGERROR)


def run_wizard():
    dialog = xbmcgui.Dialog()
    dialog.notification("LeoWizard", "Installiere komplettes Kodi-Paket...", xbmcgui.NOTIFICATION_INFO, 3000)

    # Schritt 0: Unerwünschte Addons entfernen oder deaktivieren
    purge_blocked_addons()
    xbmc.sleep(1000)

    # Schritt 1: Externe ZIP herunterladen
    if not download_file(BUILD_ZIP_URL, DOWNLOADED_ZIP):
        dialog.ok("Fehler", "Build konnte nicht heruntergeladen werden.")
        return

    # Schritt 2: ZIP nach Kodi-Home entpacken
    # Erwartete ZIP-Struktur:
    # addons/...
    # addon_data/...
    extract_build_zip(DOWNLOADED_ZIP)

    # Schritt 3: Addon-Manager aktualisieren
    dialog.notification("LeoWizard", "Update Local Addons...", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.sleep(5000)

    # Schritt 4: Alle Addons aktivieren
    enable_all_addons()
    xbmc.sleep(2000)

    # Schritt 4b: Blockierte Addons sicherheitshalber nochmal deaktivieren
    disable_blocked_addons_if_present()
    xbmc.sleep(1000)

    # Schritt 5: guisettings.xml und sources.xml kopieren
    dialog.notification("LeoWizard", "Kopiere Einstellungen...", xbmcgui.NOTIFICATION_INFO, 3000)
    try:
        shutil.copyfile(SRC_GUISETTINGS, DEST_GUISETTINGS)
        shutil.copyfile(SRC_SOURCES, DEST_SOURCES)
    except FileNotFoundError:
        log("guisettings.xml oder sources.xml nicht gefunden.", xbmc.LOGERROR)

    # Schritt 6: Skin setzen
    set_skin("skin.bingie")
    xbmc.sleep(5000)

    # Schritt 7: Skin neu laden, damit Settings greifen
    xbmc.executebuiltin("ReloadSkin()")
    xbmc.sleep(2000)

    # Schritt 8: Download-ZIP löschen
    cleanup_downloaded_zip()

    # Schritt 9: Abschlussmeldung
    dialog.ok("Wizard abgeschlossen", "Kodi wird in 5 Sekunden neu gestartet")

    # Schritt 10: Ordner 'packages' löschen
    packages_path = xbmcvfs.translatePath(os.path.join(KODI_HOME, 'addons', 'packages'))
    if os.path.exists(packages_path):
        shutil.rmtree(packages_path, ignore_errors=True)
        log("Ordner 'packages' wurde gelöscht.", xbmc.LOGINFO)

    # Schritt 11: Neustart
    xbmc.sleep(5000)
    xbmc.executebuiltin("RestartApp")


if __name__ == "__main__":
    run_wizard()