# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import urllib.parse as urlparse
import os
import re

ADDON = xbmcaddon.Addon('plugin.video.mymovies')
ADDON_ID = ADDON.getAddonInfo('id')

PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CAT_FILE = os.path.join(PROFILE_PATH, 'categories.json')
MOVIES_PATH = os.path.join(PROFILE_PATH, 'movies')
MYMOVIES_FILE = os.path.join(PROFILE_PATH, 'mymovies.json')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def normalize_url(url):
    url = urlparse.unquote((url or '').replace('&mymovies=1', '').strip())
    normalized = url.lower()

    if normalized.startswith('playmedia('):
        match = re.match(r'playmedia\("?(.*?)"?\)$', normalized, re.IGNORECASE | re.DOTALL)
        if match:
            url = urlparse.unquote(match.group(1).strip())
    elif normalized.startswith('activatewindow(10025,"plugin'):
        match = re.match(r'activatewindow\(10025,"(plugin://[^"]+)",return\)', url, re.IGNORECASE)
        if match:
            url = match.group(1)

    return url.lower()


def ensure_files():
    try:
        if not xbmcvfs.exists(PROFILE_PATH):
            xbmcvfs.mkdirs(PROFILE_PATH)

        if not xbmcvfs.exists(CAT_FILE):
            default_cats = ["Horror", "Comedy", "Drama", "Anime", "Series"]
            with xbmcvfs.File(CAT_FILE, 'w') as f:
                f.write(bytearray(json.dumps(default_cats, ensure_ascii=False), 'utf-8'))

        if not xbmcvfs.exists(MOVIES_PATH):
            xbmcvfs.mkdirs(MOVIES_PATH)

        if not xbmcvfs.exists(MYMOVIES_FILE):
            with xbmcvfs.File(MYMOVIES_FILE, 'w') as f:
                f.write(bytearray(json.dumps([], ensure_ascii=False), 'utf-8'))

    except Exception as e:
        log(f"Error in ensure_files: {e}", xbmc.LOGERROR)


def read_json_file(path, default):
    try:
        if not xbmcvfs.exists(path):
            return default

        with xbmcvfs.File(path, 'r') as f:
            data = f.read()
            if isinstance(data, bytes):
                data = data.decode('utf-8', errors='ignore')

        if not data:
            return default

        parsed = json.loads(data)
        return parsed
    except Exception as e:
        log(f"Error reading JSON file {path}: {e}", xbmc.LOGERROR)
        return default


def write_json_file(path, data):
    try:
        with xbmcvfs.File(path, 'w') as f:
            f.write(bytearray(json.dumps(data, ensure_ascii=False), 'utf-8'))
        return True
    except Exception as e:
        log(f"Error writing JSON file {path}: {e}", xbmc.LOGERROR)
        return False


def read_categories():
    ensure_files()
    categories = read_json_file(CAT_FILE, ["Horror", "Comedy", "Drama", "Anime", "Series"])
    if not isinstance(categories, list):
        return ["Horror", "Comedy", "Drama", "Anime", "Series"]
    return categories


def read_movies():
    ensure_files()
    movies = read_json_file(MYMOVIES_FILE, [])
    return movies if isinstance(movies, list) else []


def read_category_movies(category):
    if not category:
        return []
    cat_file = os.path.join(MOVIES_PATH, f"{category}.json")
    movies = read_json_file(cat_file, [])
    return movies if isinstance(movies, list) else []


def movie_exists_anywhere(title, stream_url):
    clean_title = (title or '').strip()
    clean_stream_url = normalize_url(stream_url)

    for movie in read_movies():
        if movie.get('title', '').strip() == clean_title and normalize_url(movie.get('stream_url', '')) == clean_stream_url:
            return True

    for category in read_categories():
        for movie in read_category_movies(category):
            if movie.get('title', '').strip() == clean_title and normalize_url(movie.get('stream_url', '')) == clean_stream_url:
                return True

    return False


def get_listitem_title():
    return (
        xbmc.getInfoLabel('ListItem.Title') or
        xbmc.getInfoLabel('ListItem.Label') or
        xbmc.getInfoLabel('ListItem.Label2') or
        ''
    ).strip()


def get_listitem_thumb():
    return (
        xbmc.getInfoLabel('ListItem.Art(thumb)') or
        xbmc.getInfoLabel('ListItem.Art(poster)') or
        xbmc.getInfoLabel('ListItem.Art(icon)') or
        xbmc.getInfoLabel('ListItem.Thumb') or
        xbmc.getInfoLabel('ListItem.Icon') or
        ''
    ).strip()


def get_listitem_stream_url():
    return (
        xbmc.getInfoLabel('ListItem.FileNameAndPath') or
        xbmc.getInfoLabel('ListItem.Path') or
        xbmc.getInfoLabel('ListItem.Filename') or
        ''
    ).strip()


def main():
    try:
        ensure_files()

        title = get_listitem_title()
        thumb = get_listitem_thumb()
        stream_url = get_listitem_stream_url()

        log(f"Context import values - Title: '{title}', Thumb: '{thumb}', Stream-URL: '{stream_url}'", xbmc.LOGDEBUG)

        if not title or not stream_url:
            log(f"Context import failed: Missing or invalid data - Title: '{title}', Stream-URL: '{stream_url}'", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('MyMovies', 'Missing title or stream URL', xbmcgui.NOTIFICATION_ERROR, 1500)
            return

        if movie_exists_anywhere(title, stream_url):
            log(f"Movie already exists somewhere: '{title}'", xbmc.LOGINFO)
            xbmcgui.Dialog().notification('MyMovies', f'Already exists: {title}', xbmcgui.NOTIFICATION_INFO, 1500)
            return

        categories = read_categories()
        log(f"Loaded categories: {categories}", xbmc.LOGDEBUG)

        categories = sorted(categories, key=str.lower)
        categories.append('No category')
        categories.append('Create new category')

        dialog = xbmcgui.Dialog()
        selected = dialog.select('Choose category', categories)

        if selected == -1:
            log("Category selection canceled", xbmc.LOGDEBUG)
            return

        if selected == len(categories) - 2:
            category = ''
            log("No category selected", xbmc.LOGDEBUG)

        elif selected == len(categories) - 1:
            new_category = dialog.input('New category').strip()
            if not new_category:
                log("No new category entered", xbmc.LOGDEBUG)
                xbmcgui.Dialog().notification('MyMovies', 'No category name entered', xbmcgui.NOTIFICATION_INFO, 1500)
                return

            existing_categories = categories[:-2]
            if new_category in existing_categories:
                xbmcgui.Dialog().notification('MyMovies', f'Category "{new_category}" already exists', xbmcgui.NOTIFICATION_INFO, 1500)
                return

            existing_categories.append(new_category)
            existing_categories = sorted(existing_categories, key=str.lower)

            if not write_json_file(CAT_FILE, existing_categories):
                xbmcgui.Dialog().notification('MyMovies', 'Failed to create category', xbmcgui.NOTIFICATION_ERROR, 1500)
                return

            category = new_category
            log(f"New category created: {new_category}", xbmc.LOGDEBUG)

        else:
            category = categories[selected]

        log(f"Selected category: {category}", xbmc.LOGDEBUG)

        params = {
            'action': 'import_from_context',
            'title': title,
            'thumb': thumb,
            'stream_url': stream_url,
            'cat': category
        }

        plugin_url = f"plugin://plugin.video.mymovies/?{urlparse.urlencode(params, quote_via=urlparse.quote)}"
        log(f"Calling plugin URL: {plugin_url}", xbmc.LOGDEBUG)
        xbmc.executebuiltin(f'RunPlugin({plugin_url})')

    except Exception as e:
        log(f"Error in context menu: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('MyMovies', f'Import error: {str(e)}', xbmcgui.NOTIFICATION_ERROR, 1500)


if __name__ == '__main__':
    main()